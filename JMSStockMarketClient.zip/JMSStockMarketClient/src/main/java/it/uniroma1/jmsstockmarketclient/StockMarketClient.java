package it.uniroma1.jmsstockmarketclient;

import it.uniroma1.jmsstockmarketclient.gui.AzioniFrame;

public class StockMarketClient {
	public static void main(String[] args) {
		new AzioniFrame();
	}
}
