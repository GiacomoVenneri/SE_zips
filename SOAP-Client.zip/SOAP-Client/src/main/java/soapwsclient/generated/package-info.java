@javax.xml.bind.annotation.XmlSchema(namespace = "http://soapws.softeng.sapienza.it/")
package soapwsclient.generated;
