/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.softeng.soapws;
// in this file we define the WSDLInterface
import java.util.Map;
import javax.jws.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
//this sign that we are defining an wsdl interface
@WebService
public interface WSInterface {

    public String hello(String name);

    public String helloStudent(Student student);
    //for complex type you shoud specify what is the class the will marshal and unmarshal that type.
    // in this case the complex type is Map<>
    @XmlJavaTypeAdapter(StudentMapAdapter.class)
    public Map<Integer, Student> getStudents();
}
