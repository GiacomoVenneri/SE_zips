/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_client;

/**
 *
 * @author biar
 */

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import it.uniroma1.gRPC.BookInfoRequest;
import it.uniroma1.gRPC.BookInfoResponse;
import it.uniroma1.gRPC.BookInfoServiceGrpc;
import it.uniroma1.gRPC.BooksListRequest;
import it.uniroma1.gRPC.BooksListResponse;
import it.uniroma1.gRPC.BooksListServiceGrpc;


import java.util.List;
import java.util.Map;
import soapwsclient.generated.*;

public class Client_gRPC {
    public static void main(String[] args) throws InterruptedException {
        
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
            .usePlaintext()
            .build();
        
        BookInfoServiceGrpc.BookInfoServiceBlockingStub stub 
          = BookInfoServiceGrpc.newBlockingStub(channel);
        
        
        
        BooksListServiceGrpc.BooksListServiceBlockingStub stub_2 
          = BooksListServiceGrpc.newBlockingStub(channel);

        

        
        
   
        
        
       
    String input = "";
    while(!input.equals("OUT")){
        System.out.print("Enter something here : ");

        try{
            BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
            input = bufferRead.readLine();
            if(input.equals("book_info")){
                System.out.print("Type ID of the book : ");
                bufferRead = new BufferedReader(new InputStreamReader(System.in));
                String id_input = bufferRead.readLine();
                BookInfoResponse helloResponse = stub.bookData(BookInfoRequest.newBuilder()
                .setID(id_input)
                .build());
        
                System.out.println("infosul libro richiesto:\n" + helloResponse);
                System.out.println(Client_gRPC.getHim(id_input).getName());
                System.out.println(Client_gRPC.getHim(id_input).getPrice());
            }
            if(input.equals("books")){
                BooksListResponse listResponse = stub_2.booksList(BooksListRequest.newBuilder()
                .build());
        
                System.out.println("libri disponibili:\n" + listResponse);
                
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    channel.shutdown();

  }  
        
       
    
   
    
    private static Student getHim(String ID) {
        WSImplService service = new WSImplService();
        WSInterface port = service.getWSImplPort();
        return port.getHim(ID);
    }
    
   
}
