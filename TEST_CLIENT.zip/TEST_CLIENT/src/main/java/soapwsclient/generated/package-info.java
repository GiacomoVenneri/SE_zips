@javax.xml.bind.annotation.XmlSchema(namespace = "http://test_soap_service.mycompany.com/")
package soapwsclient.generated;
