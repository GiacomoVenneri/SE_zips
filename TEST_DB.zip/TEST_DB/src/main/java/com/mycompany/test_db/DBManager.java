/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_db;

import java.sql.*;
/**
 * 
 * @author biar
 */
public class DBManager {
    
    public static void main(String[] args) throws Exception {

        Class.forName("org.sqlite.JDBC");
        Connection conn
                = DriverManager.getConnection("jdbc:sqlite:"+args[0]);
        
        Statement stat = conn.createStatement();

        if (args[1].equals("create")) {
            
            stat.executeUpdate("drop table if exists authors;");
            stat.executeUpdate("create table authors (authorID, name, birth);");
            
            stat.executeUpdate("drop table if exists books;");
            stat.executeUpdate("create table books (ID, title, year, authorID references authors(authorID));");
            
            
            
            PreparedStatement prep = conn.prepareStatement(
                    "insert into books values (?, ?, ?, ?);");
            prep.setString(1, "1");
            prep.setString(2, "HarryPotter");
            prep.setString(3, "2000");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep = conn.prepareStatement(
                    "insert into authors values(?, ?, ?);");
            prep.setString(1, "1");
            prep.setString(2, "JKR");
            prep.setString(3, "1960");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
        
        } else {
            System.out.println(args[0]);
            ResultSet rs = stat.executeQuery("select * from books;");
            while (rs.next()) {
                System.out.print("books = " + rs.getString("ID") + ": ");
                System.out.print(rs.getString("title") + ", done by authorID --->  ");
                System.out.println(rs.getString("authorID"));
            }
            rs.close();
            
            System.out.println("Now the authors.....");
            
            rs = stat.executeQuery("select * from authors;");
            while (rs.next()) {
                System.out.print("author = " + rs.getString("authorID") + ": ");
                System.out.println(rs.getString("name"));
              
            }
            rs.close();
        }
        conn.close();
    }
    
}
