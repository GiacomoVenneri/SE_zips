/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_soap_service;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author biar
 */
@XmlType(name = "Student")
public class StudentImpl implements Student {
    private String name;
    private Double price;
    
    
    public Double getPrice() {return price;}
    public String getName() { return name; }
    
    
    public void setPrice(Double d) { price = d;}
    public void setName(String n) { name = n; }

    
    public StudentImpl(String n, Double p) { name = n; price = p;} 
    public StudentImpl() {}
    
}
