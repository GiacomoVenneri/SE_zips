    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_soap_service;

import java.util.Map;
import javax.jws.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/**
 *
 * @author biar
 */
@WebService
public interface WSInterface {
    

    public Student getHim(String ID);
    
}
