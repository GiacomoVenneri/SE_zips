/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_grpc_server;

/**
 *
 * @author biar
 */

import io.grpc.stub.StreamObserver;
import it.uniroma1.gRPC.BookInfoRequest;
import it.uniroma1.gRPC.BookInfoResponse;
import it.uniroma1.gRPC.BookInfoServiceGrpc.BookInfoServiceImplBase;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class BookInfoServiceImpl extends BookInfoServiceImplBase{
    private Connection conn;
    private String pos = "/home/biar/Desktop/esercitazioni/database_exam";
    
    @Override
    // you have to implement the method presents is the interface
    // in our case we have only one method that is hello
    public void bookData(
      // maybe they are autogenrated
      BookInfoRequest request, StreamObserver<BookInfoResponse> responseObserver) {

        System.out.println("... the server has received this book ID: " + request.getID());
        
        
        //ACCESS TO DB
        ///home/biar/Desktop/esercitazioni/database_exam
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex) {
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        String ID = request.getID();
        String title = "";
        String year = "";
        String authorID = "";
        String name_author = "";
        String birth_author = "";
        
        // ACCESS TO BOOKS TABLE
        try {

            PreparedStatement stat = conn.prepareStatement("select * from books where ID = ?;");
            stat.setString(1, String.valueOf("1"));
            ResultSet rs = stat.executeQuery();
        
        if (rs.next()) {
            
            ID = rs.getString("ID");
            title = rs.getString("title");
            year = rs.getString("year");
            authorID = rs.getString("authorID");
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.INFO, "Accessed to books");
            
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // ACCESS TO AUTHORS TABLE
        
        try {

            PreparedStatement stat = conn.prepareStatement("select * from authors where authorID = ?;");
            stat.setString(1, String.valueOf(authorID));
            ResultSet rs = stat.executeQuery();
        
        if (rs.next()) {
            
            name_author = rs.getString("name");
            birth_author = rs.getString("birth");
                Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.INFO, "Accessed to autorhs");
            
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
      
       
        
        
        
        
        
        
        BookInfoResponse response = BookInfoResponse.newBuilder()
          .setTitle(title)
          .setYear(year)
          .setAuthorName(name_author)
          .setAuthorBirth(birth_author)
          .build();


        
        //next response avalaible
        responseObserver.onNext(response);
        //stub you can read a respons
        responseObserver.onCompleted();
        
    }
    
    
}
