/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_grpc_server;

/**
 *
 * @author biar
 */

import io.grpc.stub.StreamObserver;
import it.uniroma1.gRPC.BooksListRequest;
import it.uniroma1.gRPC.BooksListResponse;
import it.uniroma1.gRPC.BooksListServiceGrpc.BooksListServiceImplBase;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BooksListServiceImpl extends BooksListServiceImplBase {
    
    private Connection conn;
    private String pos = "/home/biar/Desktop/esercitazioni/database_exam";
    
    @Override
    public void booksList(BooksListRequest request, StreamObserver<BooksListResponse> responseObserver){
        System.out.println("...Richiesta dei libri");
        
        String books = "";
        
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex) {
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        try {

            PreparedStatement stat = conn.prepareStatement("select * from books;");
            ResultSet rs = stat.executeQuery();
        
        while(rs.next()) {
            books += "[ ";
            books += rs.getString("ID") + ", ";
            books += rs.getString("title") + ", ";
            books += rs.getString("year") + ", ";
            books += rs.getString("authorID");
            
            books += " ], ";
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.INFO, "Accessed to books");
            
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(BookInfoServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        BooksListResponse response = BooksListResponse.newBuilder()
          .setBooks(books)
          .build();


        
        //next response avalaible
        responseObserver.onNext(response);
        //stub you can read a respons
        responseObserver.onCompleted();
    }
    
}
