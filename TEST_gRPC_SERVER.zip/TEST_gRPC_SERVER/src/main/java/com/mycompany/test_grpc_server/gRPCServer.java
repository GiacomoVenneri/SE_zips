/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test_grpc_server;

/**
 *
 * @author biar
 */

import io.grpc.Server;
import io.grpc.ServerBuilder;
import java.io.IOException;

public class gRPCServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        Server server;
        server = ServerBuilder
                .forPort(8080)
                .addService(new BookInfoServiceImpl())
                .addService(new BooksListServiceImpl()).build();

        server.start();
        server.awaitTermination();
    }
    
}
